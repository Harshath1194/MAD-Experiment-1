package com.example.ex1

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var textView: TextView
    private lateinit var buttonChangeColor: Button
    private lateinit var buttonChangeFontSize: Button

    private val colors = arrayOf(Color.RED, Color.BLUE, Color.GREEN, Color.MAGENTA, Color.CYAN)
    private val fontSizes = arrayOf(16f, 20f, 24f, 28f, 32f)

    private var currentColorIndex = 0
    private var currentFontSizeIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById(R.id.textView)
        buttonChangeColor = findViewById(R.id.buttonChangeColor)
        buttonChangeFontSize = findViewById(R.id.buttonChangeFontSize)

        // Change text color when button is clicked
        buttonChangeColor.setOnClickListener {
            currentColorIndex = (currentColorIndex + 1) % colors.size
            textView.setTextColor(colors[currentColorIndex])
            Toast.makeText(this, "Color Changed", Toast.LENGTH_SHORT).show()
        }

        // Change text size when button is clicked
        buttonChangeFontSize.setOnClickListener {
            currentFontSizeIndex = (currentFontSizeIndex + 1) % fontSizes.size
            textView.textSize = fontSizes[currentFontSizeIndex]
            Toast.makeText(this, "Font Size Changed", Toast.LENGTH_SHORT).show()
        }
    }
}
